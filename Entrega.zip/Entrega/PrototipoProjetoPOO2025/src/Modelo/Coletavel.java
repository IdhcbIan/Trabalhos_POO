package Modelo;

public interface Coletavel {
    public boolean foiColetado();
}